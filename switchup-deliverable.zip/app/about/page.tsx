'use client';

import { motion } from 'framer-motion';
import Section from '@/components/ui/Section';
import Container from '@/components/ui/Container';
import Footer from '@/components/Footer';

export default function AboutPage() {
  const values = [
    {
      icon: '🎯',
      title: 'Mission-Driven',
      description: 'Connecting people through meaningful experiences',
    },
    {
      icon: '🌟',
      title: 'Quality First',
      description: 'Curated events with verified superhosts',
    },
    {
      icon: '🤝',
      title: 'Community',
      description: 'Building authentic connections that last',
    },
    {
      icon: '🚀',
      title: 'Innovation',
      description: 'Constantly improving the event experience',
    },
  ];

  const team = [
    { name: 'Alex Johnson', role: 'CEO & Founder', avatar: '👨‍💼' },
    { name: 'Sarah Chen', role: 'CTO', avatar: '👩‍💻' },
    { name: 'Marcus Williams', role: 'Head of Community', avatar: '👨‍🎤' },
    { name: 'Emily Rodriguez', role: 'Head of Design', avatar: '👩‍🎨' },
  ];

  return (
    <main className="pt-24">
      {/* Hero Section */}
      <Section className="relative min-h-[60vh] flex items-center bg-gradient-to-br from-light-blue via-white to-light-blue dark:from-dark-navy dark:via-dark-black dark:to-dark-navy">
        <Container>
          <motion.div
            className="max-w-4xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="gradient-text">About SwitchUp</span>
            </h1>
            <p className="text-xl md:text-2xl text-light-secondary dark:text-dark-slate">
              We're on a mission to revolutionize how people discover and experience events
            </p>
          </motion.div>
        </Container>
      </Section>

      {/* Story Section */}
      <Section className="bg-white dark:bg-dark-black">
        <Container>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Our <span className="gradient-text">Story</span>
              </h2>
              <div className="space-y-4 text-lg text-light-secondary dark:text-dark-slate">
                <p>
                  SwitchUp was born from a simple idea: finding great events shouldn't be hard.
                  Whether you're looking for a casual house party or a professional networking event,
                  everything should be in one place.
                </p>
                <p>
                  We built SwitchUp to bridge the gap between formal and informal experiences,
                  creating a platform where hosts and attendees can connect authentically.
                </p>
                <p>
                  Today, we're proud to serve over 100,000 users across 100+ cities, facilitating
                  thousands of incredible experiences every month.
                </p>
              </div>
            </motion.div>
            <motion.div
              className="relative aspect-square rounded-3xl bg-gradient-blue-purple p-1"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
            >
              <div className="w-full h-full rounded-3xl bg-white dark:bg-dark-black flex items-center justify-center text-8xl">
                🎉
              </div>
            </motion.div>
          </div>
        </Container>
      </Section>

      {/* Values Section */}
      <Section className="bg-gradient-to-br from-light-blue to-white dark:from-dark-navy to-dark-black">
        <Container>
          <motion.h2
            className="text-4xl md:text-5xl font-bold text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Our <span className="gradient-text">Values</span>
          </motion.h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                className="glass-card text-center"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.05 }}
              >
                <div className="text-6xl mb-4">{value.icon}</div>
                <h3 className="text-2xl font-bold mb-3">{value.title}</h3>
                <p className="text-light-secondary dark:text-dark-slate">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </Container>
      </Section>

      {/* Team Section */}
      <Section className="bg-white dark:bg-dark-black">
        <Container>
          <motion.h2
            className="text-4xl md:text-5xl font-bold text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Meet the <span className="gradient-text">Team</span>
          </motion.h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <motion.div
                  className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-blue-indigo flex items-center justify-center text-6xl"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  {member.avatar}
                </motion.div>
                <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                <p className="text-light-secondary dark:text-dark-slate">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </Container>
      </Section>

      {/* CTA Section */}
      <Section className="bg-gradient-blue-purple text-white text-center">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Join Our Journey
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Be part of the movement that's changing how people experience events
            </p>
            <motion.button
              className="px-10 py-5 rounded-full bg-white text-light-text font-semibold text-lg hover:scale-105 transform transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Download the App
            </motion.button>
          </motion.div>
        </Container>
      </Section>

      <Footer />
    </main>
  );
}
