'use client';

import { motion } from 'framer-motion';
import Section from '@/components/ui/Section';
import Container from '@/components/ui/Container';
import Footer from '@/components/Footer';
import { useState } from 'react';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  return (
    <main className="pt-24">
      <Section className="min-h-screen bg-gradient-to-br from-light-blue via-white to-light-blue dark:from-dark-navy dark:via-dark-black dark:to-dark-navy">
        <Container>
          <motion.div
            className="max-w-2xl mx-auto text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="gradient-text">Get In Touch</span>
            </h1>
            <p className="text-xl text-light-secondary dark:text-dark-slate">
              Have questions? We'd love to hear from you.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Contact Form */}
            <motion.div
              className="glass-card"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl glass-effect border border-light-primary/20 dark:border-dark-neon/20 focus:outline-none focus:border-light-primary dark:focus:border-dark-neon transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl glass-effect border border-light-primary/20 dark:border-dark-neon/20 focus:outline-none focus:border-light-primary dark:focus:border-dark-neon transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Subject</label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl glass-effect border border-light-primary/20 dark:border-dark-neon/20 focus:outline-none focus:border-light-primary dark:focus:border-dark-neon transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Message</label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={6}
                    className="w-full px-6 py-4 rounded-2xl glass-effect border border-light-primary/20 dark:border-dark-neon/20 focus:outline-none focus:border-light-primary dark:focus:border-dark-neon transition-colors resize-none"
                    required
                  />
                </div>
                <motion.button
                  type="submit"
                  className="w-full px-8 py-4 rounded-full bg-gradient-blue-indigo text-white font-semibold hover:scale-105 transform transition-all duration-300 shadow-lg"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Send Message
                </motion.button>
              </form>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              className="space-y-8"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="glass-card">
                <div className="text-4xl mb-4">📧</div>
                <h3 className="text-xl font-bold mb-2">Email Us</h3>
                <p className="text-light-secondary dark:text-dark-slate">support@switchup.com</p>
              </div>
              <div className="glass-card">
                <div className="text-4xl mb-4">💬</div>
                <h3 className="text-xl font-bold mb-2">Live Chat</h3>
                <p className="text-light-secondary dark:text-dark-slate">Available 24/7 in the app</p>
              </div>
              <div className="glass-card">
                <div className="text-4xl mb-4">🌐</div>
                <h3 className="text-xl font-bold mb-2">Social Media</h3>
                <p className="text-light-secondary dark:text-dark-slate">Follow us for updates</p>
              </div>
            </motion.div>
          </div>
        </Container>
      </Section>

      <Footer />
    </main>
  );
}
