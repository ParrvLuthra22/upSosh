'use client';

import { motion } from 'framer-motion';
import Section from '@/components/ui/Section';
import Container from '@/components/ui/Container';
import Footer from '@/components/Footer';

export default function SuperhostPage() {
  const benefits = [
    { icon: '⭐', title: 'Verified Badge', description: 'Stand out with an official Superhost badge' },
    { icon: '📈', title: 'Priority Listing', description: 'Get featured at the top of search results' },
    { icon: '💰', title: 'Higher Earnings', description: 'Earn more with premium pricing options' },
    { icon: '🎯', title: 'Advanced Analytics', description: 'Access detailed insights about your events' },
    { icon: '🤝', title: 'Dedicated Support', description: '24/7 priority customer support' },
    { icon: '🏆', title: 'Exclusive Perks', description: 'Special rewards and recognition' },
  ];

  return (
    <main className="pt-24">
      <Section className="min-h-[70vh] flex items-center bg-gradient-to-br from-light-primary via-light-indigo to-dark-purple text-white">
        <Container>
          <motion.div
            className="max-w-4xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <motion.div
              className="inline-block text-8xl mb-6"
              animate={{ rotate: [0, -10, 10, 0], scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              ⭐
            </motion.div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Become a Superhost
            </h1>
            <p className="text-xl md:text-2xl mb-8">
              Join our elite community of trusted event hosts and unlock exclusive benefits
            </p>
            <motion.button
              className="px-10 py-5 rounded-full bg-white text-light-text font-semibold text-lg hover:scale-105 transform transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Apply Now
            </motion.button>
          </motion.div>
        </Container>
      </Section>

      <Section className="bg-white dark:bg-dark-black">
        <Container>
          <motion.h2
            className="text-4xl md:text-5xl font-bold text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="gradient-text">Superhost Benefits</span>
          </motion.h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                className="glass-card"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10 }}
              >
                <div className="text-5xl mb-4">{benefit.icon}</div>
                <h3 className="text-2xl font-bold mb-3">{benefit.title}</h3>
                <p className="text-light-secondary dark:text-dark-slate">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </Container>
      </Section>

      <Footer />
    </main>
  );
}
