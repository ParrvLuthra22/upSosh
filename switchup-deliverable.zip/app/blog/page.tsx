'use client';

import { motion } from 'framer-motion';
import Section from '@/components/ui/Section';
import Container from '@/components/ui/Container';
import Footer from '@/components/Footer';

export default function BlogPage() {
  const posts = [
    {
      title: 'How to Host the Perfect House Party',
      excerpt: 'Tips and tricks for creating unforgettable experiences in your own space',
      category: 'Hosting Tips',
      date: 'Dec 1, 2025',
      image: '🎉',
    },
    {
      title: 'The Rise of Informal Networking Events',
      excerpt: 'Why casual meetups are becoming the new way to build professional connections',
      category: 'Trends',
      date: 'Nov 28, 2025',
      image: '🤝',
    },
    {
      title: 'Safety First: Event Attendance Guide',
      excerpt: 'Essential safety tips for attending events through SwitchUp',
      category: 'Safety',
      date: 'Nov 25, 2025',
      image: '🛡️',
    },
    {
      title: 'Becoming a Superhost: Success Stories',
      excerpt: 'Learn from our top hosts about building a thriving event business',
      category: 'Superhost',
      date: 'Nov 20, 2025',
      image: '⭐',
    },
    {
      title: 'Workshop Hosting 101',
      excerpt: 'Everything you need to know about hosting educational events',
      category: 'Education',
      date: 'Nov 15, 2025',
      image: '💼',
    },
    {
      title: 'Building Community Through Events',
      excerpt: 'How SwitchUp is bringing people together in meaningful ways',
      category: 'Community',
      date: 'Nov 10, 2025',
      image: '🌟',
    },
  ];

  return (
    <main className="pt-24">
      {/* Hero */}
      <Section className="bg-gradient-to-br from-light-blue via-white to-light-blue dark:from-dark-navy dark:via-dark-black dark:to-dark-navy">
        <Container>
          <motion.div
            className="max-w-4xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="gradient-text">SwitchUp Blog</span>
            </h1>
            <p className="text-xl text-light-secondary dark:text-dark-slate">
              Stories, tips, and insights from the world of events
            </p>
          </motion.div>
        </Container>
      </Section>

      {/* Blog Posts Grid */}
      <Section className="bg-white dark:bg-dark-black">
        <Container>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post, index) => (
              <motion.article
                key={index}
                className="glass-card group cursor-pointer"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10 }}
              >
                <div className="text-6xl mb-4">{post.image}</div>
                <div className="text-sm text-light-primary dark:text-dark-neon font-semibold mb-2">
                  {post.category}
                </div>
                <h2 className="text-2xl font-bold mb-3 group-hover:gradient-text transition-all duration-300">
                  {post.title}
                </h2>
                <p className="text-light-secondary dark:text-dark-slate mb-4">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-light-secondary dark:text-dark-slate">
                    {post.date}
                  </span>
                  <span className="text-light-primary dark:text-dark-neon font-semibold group-hover:underline">
                    Read More →
                  </span>
                </div>
              </motion.article>
            ))}
          </div>
        </Container>
      </Section>

      <Footer />
    </main>
  );
}
