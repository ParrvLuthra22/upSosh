'use client';

import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function SuperhostPage() {
    const heroRef = useRef(null);
    const stepsRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const ctx = gsap.context(() => {
            gsap.from(heroRef.current, {
                y: 30,
                opacity: 0,
                duration: 1,
                delay: 0.2,
            });

            const steps = stepsRef.current?.children;
            if (steps) {
                gsap.from(steps, {
                    x: -50,
                    opacity: 0,
                    duration: 0.8,
                    stagger: 0.3,
                    scrollTrigger: {
                        trigger: stepsRef.current,
                        start: 'top 70%',
                    },
                });
            }
        });
        return () => ctx.revert();
    }, []);

    return (
        <div className="min-h-screen pt-24 pb-12">
            {/* Hero */}
            <section className="container mx-auto px-4 mb-24">
                <div ref={heroRef} className="flex flex-col md:flex-row items-center gap-12">
                    <div className="md:w-1/2">
                        <div className="inline-block px-4 py-2 rounded-full bg-accent/10 border border-accent/20 text-accent font-bold text-sm mb-6">
                            For Elite Hosts
                        </div>
                        <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6 leading-tight">
                            Become a <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-purple-500">Superhost</span>
                        </h1>
                        <p className="text-xl text-text-secondary mb-8 leading-relaxed">
                            Unlock exclusive benefits, lower fees, and premium visibility. Join the top 1% of creators on SwitchUp.
                        </p>
                        <div className="flex gap-4">
                            <button className="bg-accent text-white px-8 py-4 rounded-xl font-bold hover:bg-accent/90 transition-colors shadow-lg shadow-accent/20">
                                Apply Now
                            </button>
                            <button className="px-8 py-4 rounded-xl border border-white/10 hover:bg-white/5 transition-colors font-medium">
                                Learn More
                            </button>
                        </div>
                    </div>
                    <div className="md:w-1/2 relative">
                        <div className="aspect-square rounded-3xl bg-gradient-to-tr from-accent/20 to-purple-500/20 border border-white/10 backdrop-blur-xl flex items-center justify-center relative overflow-hidden">
                            <div className="absolute inset-0 bg-grid-white/10 [mask-image:radial-gradient(white,transparent_70%)]" />
                            <div className="w-32 h-32 bg-accent rounded-full blur-[100px] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                            <span className="text-9xl relative z-10">🌟</span>
                        </div>
                    </div>
                </div>
            </section>

            {/* Benefits Grid */}
            <section className="bg-surface-highlight/30 py-20 border-y border-white/5">
                <div className="container mx-auto px-4">
                    <h2 className="text-3xl font-heading font-bold text-center mb-16">Why become a Superhost?</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {[
                            { title: '0% Service Fees', desc: 'Keep 100% of your ticket sales. We only charge for payment processing.', icon: '💰' },
                            { title: 'Premium Badge', desc: 'Stand out with the verified Superhost badge on your profile and events.', icon: '✨' },
                            { title: 'Priority Support', desc: 'Get 24/7 dedicated support from our VIP team.', icon: '📞' },
                        ].map((benefit, i) => (
                            <div key={i} className="bg-surface p-8 rounded-2xl border border-white/5 hover:border-accent/30 transition-colors">
                                <div className="text-4xl mb-4">{benefit.icon}</div>
                                <h3 className="text-xl font-bold mb-3">{benefit.title}</h3>
                                <p className="text-text-secondary">{benefit.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Verification Steps */}
            <section className="container mx-auto px-4 py-24">
                <h2 className="text-3xl font-heading font-bold text-center mb-16">Verification Process</h2>
                <div ref={stepsRef} className="max-w-4xl mx-auto space-y-8">
                    {[
                        { step: '01', title: 'Complete Profile', desc: 'Ensure your host profile is 100% complete with a bio, photo, and social links.' },
                        { step: '02', title: 'Host 5+ Events', desc: 'Demonstrate your experience by hosting at least 5 successful events on the platform.' },
                        { step: '03', title: 'Maintain 4.8+ Rating', desc: 'Keep your attendees happy. High ratings are key to Superhost status.' },
                        { step: '04', title: 'Identity Verification', desc: 'Submit government ID for a secure background check.' },
                    ].map((item, i) => (
                        <div key={i} className="flex gap-6 items-start p-6 rounded-2xl bg-surface/50 border border-white/5 hover:bg-surface hover:border-white/10 transition-all">
                            <span className="text-4xl font-bold text-white/10 font-heading">{item.step}</span>
                            <div>
                                <h3 className="text-xl font-bold mb-2 text-text-primary">{item.title}</h3>
                                <p className="text-text-secondary">{item.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}
