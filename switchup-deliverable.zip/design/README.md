# Design Assets

This directory is reserved for design files, such as Figma exports, brand assets, and style guides.

## Contents
- [ ] Figma File (Link or Export)
- [ ] Logo Assets (SVG/PNG)
- [ ] Brand Guidelines
